package com.example.discordclone.model

data class Chat(
    val title: String,
    val description: String
)
