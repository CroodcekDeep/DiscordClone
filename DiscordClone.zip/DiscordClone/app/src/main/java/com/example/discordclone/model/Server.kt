package com.example.discordclone.model

data class Server(
    val name: String,
    val image: Int
)
