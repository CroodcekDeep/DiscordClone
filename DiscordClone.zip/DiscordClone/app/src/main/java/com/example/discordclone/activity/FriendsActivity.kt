package com.example.discordclone.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.discordclone.R

class FriendsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_friends)
    }
}