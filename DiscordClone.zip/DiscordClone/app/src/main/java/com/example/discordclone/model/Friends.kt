package com.example.discordclone.model

data class Friends(
    val name: String,
    val image: Int,
    val state: Boolean
)
