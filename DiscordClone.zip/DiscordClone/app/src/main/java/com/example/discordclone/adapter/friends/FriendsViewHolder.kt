package com.example.discordclone.adapter.friends

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.example.discordclone.model.Friends

class FriendsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    fun bind(friend: Friends) {

    }
}